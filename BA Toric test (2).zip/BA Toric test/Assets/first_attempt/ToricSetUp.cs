﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*Main Class to set up the scene
 * 
 * 
 * 
  */


public class ToricSetUp : MonoBehaviour {

    //registered targets
    public GameObject _target1;
    public GameObject _target2;

    //Number of viewpoints
    public int _steps;

    // desired on-screen positions of the targets
    public Vector2 _desPos1;
    public Vector2 _desPos2;

    //Toric surface
    private ToricManifold _toric;

    //Main camera, whose settings get copied
    private Camera _camera;

    //simply a constant
    private const float TWO_PI = 2 * Mathf.PI;

    // Use this for initialization
    void Start () {

        //finding all targets by tag (only for two targets)
        //GameObject[] targets = GameObject.FindGameObjectsWithTag("Target");
        //if (targets.Length == 2) {
        //    _target1 = targets[0];
        //    _target2 = targets[1];
        //}

        //saving target positions
        Vector3 posT1 = _target1.transform.position;
        Vector3 posT2 = _target2.transform.position;


        _camera = GetComponent<Camera>();

        //building the manifold surface
        _toric = new ToricManifold(_camera.fieldOfView, _camera.aspect, posT1,posT2,_desPos1,_desPos2);


        // we can now compute camera viewpoints which satisfy the on-screen positioning, ie on the manifold surface
        int N = _steps;
        GameObject[] cameras = new GameObject[N * N];

        //for N cameras get the theta value 
        for (int t = 0; t < N; t++)
        {
           
            float theta = _toric.GetThetaFromRatio((t + 1) / (N + 1));
           
            //for N cameras across each theta value 
            for (int p = 0; p < N; p++)
            {
                float phi = p * TWO_PI / N;

                ////DEBUG
                GameObject cam = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cam.name = "Debug" + (t * N + p);
                cameras[t * N + p] = cam;

                ////Create a camera and label it accordingly
                //GameObject cam = new GameObject("camera" + (t * N + p));
                //cam.AddComponent<Camera>();
                //cam.GetComponent<Camera>().enabled = false;
                //cameras[t * N + p] = cam;

                //Place and rotate the camera 
                cameras[t * N + p].transform.position = _toric.computePosition(theta, phi);
                cameras[t * N + p].transform.rotation = _toric.ComputeOrientation(cameras[t * N + p].transform.position);
            }
        }

    }
}
