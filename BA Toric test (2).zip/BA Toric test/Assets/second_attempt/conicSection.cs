﻿using UnityEngine;

internal interface conicSection
{
     bool IsInside(Vector3 pointToTest);
    
}