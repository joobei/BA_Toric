# BA_Toric

Repository for the Unity-Implementation of Lino's Toric space
