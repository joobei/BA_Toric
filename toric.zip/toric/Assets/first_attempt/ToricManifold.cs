﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*Class for the manifold surface
 * 
 * including two inner classes 
 * 
 * 
 * 
 */
 
public class ToricManifold {
    //Basic fields
    private double m_radius;
    private Equation m_equation;
    private Quaternion m_quat;


 
    private double Sx = 0, Sy = 0;

    //TODO Check Field of view x and y
    /***************************************************************************************************/
    /// \brief	Creates a manifold surface so that world position wposA projects at pA on the screen, and world position wposB projects at pB on the screen
    ///
    ///	\param[in]	float fovX			the horizontal field of view of the camera
    ///	\param[in]	double  aspect			the aspect ratio of the camera
    ///	\param[in]	Vector2  pA				the first target's screen position in [-1;+1]^2
    ///	\param[in]	Vector2  pB				the second target's screen position in [-1;+1]^2
    ///	\param[in]	Vector3  wposA			the first target's world position
    ///	\param[in]	Vector3  wposB			the second target's world position
    ///
    /// \author	Christophe Lino - Edited
    /// \date	2012/07/29
    /***************************************************************************************************/
    public ToricManifold(float fieldOfView, float aspect, Vector3 posT1, Vector3 posT2, Vector2 desPos1, Vector2 desPos2)
    {   
        ComputeScale(fieldOfView, aspect, Sx, Sy);

        create(Sx, Sy, desPos1, desPos2, posT1, posT2);
    }

    public void create( double Sx, double Sy, Vector3  pA,  Vector3 pB,  Vector3 wposA,  Vector3 wposB)
	{
        //Get the screen position in camera space
        Vector3 pA3 = GetVectorInCameraSystem(pA, Sx, Sy);
        Vector3 pB3 = GetVectorInCameraSystem(pB, Sx, Sy);
        //and the angle between them
        float alpha = Vector3.Angle(pA3, pB3);

        //Create the equation 
        m_equation = new Equation(wposA, wposB, alpha);

        //TODO check direction
        //Vector between the two targets
        Vector3 distanceAB = wposB - wposA;

        //-------------- edited z out

        //not needed but used in lino-library
        double AB_norm = Norm(-distanceAB);

        double t = AB_norm / (2 * Mathf.Tan(alpha));
        m_radius = AB_norm / (2 * Mathf.Sin(alpha));

        Vector3 up, right, forward;

        Vector3.Normalize(pA3);Vector3.Normalize(pB3);

        //creating the vectors for the quaternion
        up = Vector3.Cross(pB3, pA3); up.Normalize();
        forward = pB3 + pA3; forward.Normalize();


        //right = Vector3.Cross(up, forward); right.Normalize();

        m_quat = Quaternion.LookRotation(forward, up);

    }

    //copied from lino-library
    public float GetThetaFromRatio(float theta)
    {
        float alpha = m_equation.getAlpha();
        return Mathf.Deg2Rad * theta / (2 * (Mathf.PI - Mathf.Deg2Rad * alpha));
    }

    //copied from lino-library
    public Vector3 computePosition(float theta, float phi)
    {
        Toric3 t = new Toric3(m_equation.getAlpha(), theta, phi);
        return t.ToWorldPosition(t, m_equation.getA(), m_equation.getB());
    }
    

    //copied from lino-library
    //LOOKROTATION = ZERO? Unity error 
    public Quaternion ComputeOrientation(Vector3 position)
    {
            Vector3 dA = m_equation.getA()-position;
            Vector3 dB = m_equation.getB()-position;
            Vector3 right, forward, up = new Vector3();
            
                up = Vector3.Cross(dB, dA);
                up.Normalize();

                dA.Normalize();
                dB.Normalize();
                forward = dA + dB;
                forward.Normalize();

            right = Vector3.Cross(forward, up);
            right.Normalize();

        //Debug.Log(dA);
        //Debug.Log(dB);
        //Debug.Log(forward);
        //Debug.Log(up);
        Quaternion q = Quaternion.LookRotation(forward, up);

            return q * Quaternion.Inverse(m_quat);
        }
    

   

    private void ComputeScale(float fovX, double aspect, double Sx, double Sy)
    {
        double tanX = Mathf.Tan(Mathf.Deg2Rad * fovX / 2),
			tanY = tanX / aspect;
        Sx = 1.0 / tanX;
        Sy = 1.0 / tanY;
    }

    private Vector3 GetVectorInCameraSystem(Vector3 screenProj,  double Sx,  double Sy)
    {
        Vector3 vec;
        if (screenProj.z == 0)
            vec = new Vector3(screenProj.x, 0, screenProj.y);
        else
            //Check Typecast
            vec = new Vector3(screenProj.x / ((float) Sx), Mathf.Sign(screenProj.z), screenProj.y / ((float)Sy));
        return vec;
    }

    static public float Norm(Vector3 n) {
        return Mathf.Sqrt(Vector3.Dot(n,n));
    }

    /*
     * Easy saving space for the toric equation (A,B,alpha)
     * 
     * 
     */ 
    class Equation
    {
        Vector3 m_A ;
        Vector3 m_B ;
        float m_alpha;
        

        public Equation(Vector3 A, Vector3 B, float alpha)
        {
             m_A = A;
             m_B = B;
             m_alpha = alpha;
        }

        public Vector3 getA()
        {
            return m_A;
        }

        public Vector3 getB()
        {
            return m_B;
        }

        public float getAlpha()
        {
            return m_alpha;
        }
    }

    //Position on the manifold surface by theta and phi
    class Toric3
    {
        float m_theta;
        float m_phi;
        float m_alpha;


        public Toric3(float theta, float phi, float alpha)
        {
            float min_value = 0.001f;
            m_theta = Mathf.Clamp(Mathf.Deg2Rad * theta, min_value, 2 * (- Mathf.PI - min_value - Mathf.Deg2Rad * getAlpha())); 
            m_phi = phi;
            m_alpha = Mathf.Clamp(Mathf.Deg2Rad*alpha, min_value, Mathf.PI - min_value);
        }

        public float getTheta()
        {
            return m_theta;
        }

        public float getPhi()
        {
            return m_phi;
        }

        public float getAlpha()
        {
            return m_alpha;
        }

        public Vector3 ToWorldPosition(Toric3 t3, Vector3 wposA, Vector3 wposB)
        {
            Vector3 vecAB = wposB - wposA;
            float AB = ToricManifold.Norm(vecAB);

            Vector3 n = -vecAB;
            n.Normalize();
            Vector3 z = Vector3.zero;
            
            //Edited Vector z ------- maybe missing 

            // correct method?
            Quaternion qP = Quaternion.AngleAxis(t3.getPhi(),n);
            float beta = (Mathf.Deg2Rad * t3.getTheta())/ 2;

            Vector3 t = Vector3.Cross(z,n);

            Quaternion qT = Quaternion.AngleAxis( beta, t);
            float d = ComputeDistanceToA(AB, t3.getAlpha(), t3.getTheta());

            Vector3 res = qP * qT * vecAB;
            
            res = res * d / AB + wposA;

            return res;
        }


        private float ComputeDistanceToA(float aB, float v1, float v2)
        {
            return (aB * Mathf.Sin((Mathf.Deg2Rad * v1) + (Mathf.Deg2Rad* v2) / 2) / Mathf.Sin(v1));
        }
    }
}
